const emailService = require('../services/emailService');
const logger = require('../utils/logger');

class NotificationController {
  /*
   * POST /notifications/send
   * Send a notification (email)
   * Body: {
   *   userId: 'uuid',
   *   recipientEmail: 'user@example.com',
   *   
   *   // Option 1: Direct email
   *   subject: 'Subject',
   *   bodyHtml: '<p>HTML content</p>',
   *   bodyText: 'Plain text content' (optional),
   *   
   *   // Option 2: Using template by ID
   *   templateId: 'uuid',
   *   templateVariables: {} (optional),
   *   
   *   // Option 3: Using template by name
   *   templateName: 'invite',
   *   organizationId: 'uuid' (required with templateName),
   *   templateVariables: {} (optional)
   * }
   */
  async sendNotification(req, res) {
    try {
      const {
        userId,
        organizationId,
        recipientEmail,
        subject,
        bodyHtml,
        bodyText,
        templateId,      
        templateName,
        templateVariables
      } = req.body;

      // Validate required fields
      if (!userId || !recipientEmail) {
        return res.status(400).json({
          success: false,
          message: 'userId and recipientEmail are required'
        });
      }

      let notification;

      // Check if using template (by ID or name) or direct email
      if (templateId || templateName) {
        // Send with template
        
        // If using templateName, organizationId is required
        if (templateName && !organizationId) {
          return res.status(400).json({
            success: false,
            message: 'organizationId is required when using templateName'
          });
        }

        notification = await emailService.sendEmailWithTemplate({
          userId,
          organizationId,
          templateId,     
          templateName,
          recipientEmail,
          templateVariables: templateVariables || {},
          sourceService: 'notification-service',
          eventType: 'api.send'
        });
      } else {
        // Send direct email
        if (!subject || !bodyHtml) {
          return res.status(400).json({
            success: false,
            message: 'subject and bodyHtml are required for direct emails'
          });
        }

        notification = await emailService.sendDirectEmail({
          userId,
          organizationId,
          recipientEmail,
          subject,
          bodyHtml,
          bodyText,
          sourceService: 'notification-service',
          eventType: 'api.send'
        });
      }

      logger.info('Notification sent via API', { 
        notificationId: notification.id,
        userId 
      });

      return res.status(201).json({
        success: true,
        message: 'Notification sent successfully',
        data: {
          notificationId: notification.id,
          status: notification.status,
          recipientEmail: notification.recipient_email
        }
      });
    } catch (error) {
      logger.error('Error in sendNotification controller', { error });

      return res.status(500).json({
        success: false,
        message: 'Failed to send notification',
        error: error.message
      });
    }
  }
}

module.exports = new NotificationController();