const express = require('express');
const notificationController = require('../controllers/notificationController');
const logController = require('../controllers/logController');

const router = express.Router();

// POST /notifications/send - Enviar notificação
router.post('/send', notificationController.sendNotification);

// GET /notifications/logs - Listar logs (admin)
router.get('/logs', logController.getLogs);

// GET /notifications/logs/:id - Logs de uma notificação específica (admin)
router.get('/logs/:id', logController.getLogsByNotificationId);

module.exports = router;
