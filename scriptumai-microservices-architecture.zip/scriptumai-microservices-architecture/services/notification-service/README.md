# Notification Service (SEARA)

Microserviço responsável pelo envio de notificações por email no projeto ScriptumAI.

## ��� Características

- ✅ Envio de emails via SMTP
- ✅ Templates Handlebars configuráveis por organização
- ✅ Consumidor de eventos RabbitMQ
- ✅ Retry logic automático para falhas
- ✅ Logging e auditoria completa
- ✅ Database per Service (PostgreSQL)

## ��� Stack Tecnológica

- **Node.js 18+** + Express
- **PostgreSQL 15** (porta 5435)
- **RabbitMQ** (consumer)
- **Nodemailer** + Mailpit (desenvolvimento)
- **Handlebars** (templates)

## ���️ Base de Dados

**Database:** `notification_db` (porta 5435)

**Tabelas:**
- `notification_templates` - Templates configuráveis
- `notifications` - Notificações enviadas/pendentes
- `notification_logs` - Histórico de envios

## ��� Endpoints REST

### POST /notifications/send
Enviar uma notificação

**Com template:**
```json
{
  "userId": "uuid",
  "organizationId": "uuid",
  "recipientEmail": "user@example.com",
  "templateName": "invite",
  "templateVariables": {
    "organizationName": "Acme Corp",
    "inviteLink": "https://..."
  }
}
```

**Email direto:**
```json
{
  "userId": "uuid",
  "recipientEmail": "user@example.com",
  "subject": "Assunto",
  "bodyHtml": "<p>HTML</p>"
}
```

### GET /notifications/logs
Listar logs (admin only)

**Query params:**
- `status`: SENT, FAILED, PENDING
- `channel`: EMAIL
- `sourceService`: nome do serviço
- `eventType`: tipo de evento
- `startDate`, `endDate`: ISO dates
- `limit`, `offset`: paginação

### GET /notifications/logs/:id
Ver logs de uma notificação específica

## ��� Eventos RabbitMQ (Consome)

### 1. `invite.created` (Organization Service)
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "organizationId": "uuid",
  "organizationName": "Acme Corp",
  "invitedBy": "John Doe",
  "inviteToken": "token123",
  "role": "GESTOR"
}
```

### 2. `user.created` (IDP Service)
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "name": "John Doe",
  "role": "CLIENTE"
}
```

### 3. `document.uploaded` (Document Service)
```json
{
  "id": "uuid",
  "fileName": "report.pdf",
  "userId": "uuid",
  "organizationId": "uuid"
}
```

## ��� Executar Localmente

### 1. Instalar dependências
```bash
npm install
```

### 2. Configurar .env
```bash
cp .env.example .env
# Editar .env com as configurações corretas
```

### 3. Criar base de dados
```bash
# Via Docker
docker-compose up -d notification-db

# Aplicar schema
docker exec -i notification-db psql -U postgres -d notification_db < database/schema.sql
```

### 4. Executar
```bash
# Desenvolvimento
npm run dev

# Produção
npm start
```

## ��� Docker
```bash
# Build
docker build -t notification-service .

# Run
docker run -p 3005:3005 --env-file .env notification-service
```

## ��� Arquitetura
```
Notification Service (porta 3005)
├── REST API (Express)
├── RabbitMQ Consumer
├── PostgreSQL (notification_db)
├── SMTP Client (Nodemailer)
└── Handlebars Templates
```
Projeto ScriptumAI - Arquiteturas e Integração de Sistemas
